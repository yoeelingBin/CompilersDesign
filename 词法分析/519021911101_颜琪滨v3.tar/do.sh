flex ./little_lexer.l
gcc ./lex.yy.c -lfl -o little_lexer
